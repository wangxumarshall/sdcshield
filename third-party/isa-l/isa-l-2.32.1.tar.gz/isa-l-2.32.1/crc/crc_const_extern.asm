;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;  Copyright(c) 2026 Intel Corporation All rights reserved.
;
;  Redistribution and use in source and binary forms, with or without
;  modification, are permitted provided that the following conditions
;  are met:
;    * Redistributions of source code must retain the above copyright
;      notice, this list of conditions and the following disclaimer.
;    * Redistributions in binary form must reproduce the above copyright
;      notice, this list of conditions and the following disclaimer in
;      the documentation and/or other materials provided with the
;      distribution.
;    * Neither the name of Intel Corporation nor the names of its
;      contributors may be used to endorse or promote products derived
;      from this software without specific prior written permission.
;
;  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
;  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
;  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
;  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
;  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
;  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
;  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
;  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
;  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
;  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
;  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; ---------------------------------------------------------------------------
; External references to constants defined in crc_const.asm.
;
; Include this file (instead of crc_const.asm) in every CRC implementation
; that needs to reference these symbols.  crc_const.asm is assembled once
; as a standalone object; the linker resolves the references.
; ---------------------------------------------------------------------------

default rel

; CRC polynomial constant tables
extern crc32_gzip_refl_const
extern crc32_ieee_const
extern crc32_iscsi_const
extern crc16_t10dif_const
extern crc16_t10dif_copy_const
extern crc64_iso_norm_const
extern crc64_iso_refl_const
extern crc64_ecma_norm_const
extern crc64_ecma_refl_const
extern crc64_jones_norm_const
extern crc64_jones_refl_const
extern crc64_rocksoft_norm_const
extern crc64_rocksoft_refl_const

; Utility masks and shuffle tables
extern hi64_mask
extern shf_xor_mask
extern lo32_clr_mask
extern hi32_clr_mask
extern bswap_shuf_mask
extern lo64_mask
extern zero128
extern shf_table_refl
extern tail_shuf_refl
extern tail_shuf_norm
extern shf_table_norm
extern byte_len_mask_table

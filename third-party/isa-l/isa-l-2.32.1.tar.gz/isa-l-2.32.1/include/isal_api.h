/**********************************************************************
  Copyright(c) 2026 Intel Corporation All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**********************************************************************/

#ifndef _ISAL_API_H
#define _ISAL_API_H

#define ISAL_LIB_GCC_VERSION (__GNUC__ * 10000 + __GNUC_MINOR__ * 100 + __GNUC_PATCHLEVEL__)

#ifndef __has_extension
#define __has_extension(x) 0
#endif

#if (defined(__ICC) || defined(__GNUC__) || defined(__clang__)) && !defined(ISAL_UNIT_TEST) &&     \
        !defined(ISAL_DEPRECATED_INTERNAL)
#if __has_extension(attribute_deprecated_with_message) || (ISAL_LIB_GCC_VERSION >= 40500) ||       \
        (__INTEL_COMPILER >= 1100)
#define ISAL_LIB_DEPRECATED(message) __attribute__((deprecated(message)))
#else
#define ISAL_LIB_DEPRECATED(message) __attribute__((deprecated))
#endif
#elif (defined(__ICL) || defined(_MSC_VER))
#if (__INTEL_COMPILER >= 1100) || (_MSC_FULL_VER >= 140050727)
#define ISAL_LIB_DEPRECATED(message) __declspec(deprecated(message))
#else
#define ISAL_LIB_DEPRECATED(message) __declspec(deprecated)
#endif
#else
#define ISAL_LIB_DEPRECATED(message)
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* Utility macros */
#define CONCAT_VERSION_(a, b, c) a##.##b##.##c
#define CONCAT_VERSION(a, b, c)  CONCAT_VERSION_(a, b, c)
#define TO_STRING_(a)            #a
#define TO_STRING(a)             TO_STRING_(a)

/* Library version numbers */
#ifndef ISAL_MAJOR_VERSION
#define ISAL_MAJOR_VERSION 2
#endif
#ifndef ISAL_MINOR_VERSION
#define ISAL_MINOR_VERSION 32
#endif
#ifndef ISAL_PATCH_VERSION
#define ISAL_PATCH_VERSION 1
#endif

#ifndef ISAL_MAKE_VERSION
#define ISAL_MAKE_VERSION(maj, min, patch) ((maj) * 0x10000 + (min) * 0x100 + (patch))
#endif
#ifndef ISAL_VERSION
#define ISAL_VERSION ISAL_MAKE_VERSION(ISAL_MAJOR_VERSION, ISAL_MINOR_VERSION, ISAL_PATCH_VERSION)
#endif
#define ISAL_VERSION_STR                                                                           \
        TO_STRING(CONCAT_VERSION(ISAL_MAJOR_VERSION, ISAL_MINOR_VERSION, ISAL_PATCH_VERSION))

/**
 * @brief Get library version in string format
 *
 * @return library version string
 */
const char *
isal_get_version_str(void);

/**
 * @brief Get library version in numerical format
 *
 * Use ISAL_MAKE_VERSION macro to compare this
 * numerical version against known library version.
 *
 * @return library version number
 */
unsigned
isal_get_version(void);

#ifdef __cplusplus
}
#endif //__cplusplus
#endif // ifndef _ISAL_API_H
